﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
// using Spire.Xls;

namespace grafo
{
    class Program
    {
        static void Main(string[] args)
        {
            string nomeArquivo = "EntradaGrafosMaisProfessores.txt";
            string[] linhas = File.ReadLines("./files/" + nomeArquivo).ToArray();

            // string[] linhas = {
            //     "Introduçao_a_Pesquisa Josiane 1",
            //     "Introduçao_a_Pesquisa Josiane 1",
            //     "Grafos Josiane 2",
            //     "Redes Leonardo 2",
            //     "Engenharia_de_Requisitos Leonardo 3",
            //     "Politicas Reginaldo 1",
            //     "POO Reginaldo 2",
            //     "BD Wagner 1",
            //     "ATP Wagner 3",
            // };

            Grafo grafo = Grafo.CriarGrafo(linhas);

            grafo.ObterColoracao(grafo.GetProfessor("1"));
           
            grafo.OrdernarProfessoresCores();
            grafo.ListarProfessor();

            System.Console.WriteLine();

            grafo.OrdernarProfessores();
            grafo.ListarProfessor();

            System.Console.WriteLine();

            grafo.ImprimirTabela();
            System.Console.WriteLine();

            Console.WriteLine("Quantidade de cores: " + grafo.ObterQuantidadeCores());

            Console.ReadLine();

        }
    }
}