﻿using System.Collections.Generic;

namespace grafo
{
    public interface IPrintTabularData<Professor>
    {
        void PrintTable(IEnumerable<Professor> data);
    }
}
